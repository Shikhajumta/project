
import argparse

def train_model(config_path):
    print(f"Training model with configuration from {config_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train Fish Identification Model")
    parser.add_argument("--config", type=str, required=True, help="Path to the configuration file")
    args = parser.parse_args()
    train_model(args.config)
