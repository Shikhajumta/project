
import argparse

def predict(image_path, model_path):
    print(f"Predicting fish species for {image_path} using model {model_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Fish Identification Inference")
    parser.add_argument("--image", type=str, required=True, help="Path to the input image")
    parser.add_argument("--model", type=str, required=True, help="Path to the model file")
    args = parser.parse_args()
    predict(args.image, args.model)
